package com.yusuf.kotlinnotes

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        generateFakeNotes()

        list.adapter = NotesAdapter(this)

        fab.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                NoteActivity().newNote(this@MainActivity)
            }

        })
    }


    private fun generateFakeNotes() {
        NotesController.saveNote(this, Note("Note #1", "This is my first note ever!!"))
        NotesController.saveNote(this, Note("Groceries", "-Apples\n-Milk\n-Eggs"))
        NotesController.saveNote(this, Note("Business Idea", "Wouldn't it be cool if..."))
    }
}
