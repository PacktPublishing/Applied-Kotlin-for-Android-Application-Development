package com.yusuf.kotlinnotes

import android.content.Context

object NotesController {

    fun getAllNotes(context: Context): ArrayList<Note> {
        val sharedPreferences = getSharedPreferences(context)
        val notesMap = sharedPreferences.all
        val notesList: ArrayList<Note> = arrayListOf()
        notesMap.forEach {
            notesList.add(Note(it.key, it.value as String))
        }
        return notesList
    }

    fun saveNote(context: Context, note: Note) {
        val sharedPreferencesEditor = getSharedPreferences(context).edit()
        sharedPreferencesEditor.putString(note.title, note.body)
        sharedPreferencesEditor.apply()
    }


    fun deleteNote(context: Context, note: Note) {
        val sharedPreferencesEditor = getSharedPreferences(context).edit()
        sharedPreferencesEditor.remove(note.title)
        sharedPreferencesEditor.apply()
    }


    private fun getSharedPreferences(context: Context) = context.getSharedPreferences("KotlinNotes", Context.MODE_PRIVATE)
}