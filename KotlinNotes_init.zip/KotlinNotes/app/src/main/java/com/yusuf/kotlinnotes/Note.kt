package com.yusuf.kotlinnotes

import java.io.Serializable

data class Note(var title: String, var body: String): Serializable