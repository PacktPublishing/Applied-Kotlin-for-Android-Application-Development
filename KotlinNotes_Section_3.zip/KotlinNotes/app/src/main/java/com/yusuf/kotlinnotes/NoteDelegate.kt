package com.yusuf.kotlinnotes

import android.content.Context
import android.widget.Toast
import kotlin.reflect.KProperty

class NoteDelegate(val context: Context, val onSet: String, val onGet: String) {

    private var note: Note? = null

    operator fun getValue(thisRef: Any?, property: KProperty<*>): Note? {
        Toast.makeText(context, onGet, Toast.LENGTH_SHORT).show()
        return note
    }

    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: Note?) {
        note = value
        Toast.makeText(context, onSet, Toast.LENGTH_SHORT).show()
    }

}