package com.yusuf.kotlinnotes

import android.content.Context

object NotesController: Controller<Note>, DeleteNote {

    override val sharedPrefName: String
        get() = "KotlinNotes"


    override fun getAll(context: Context): ArrayList<Note> {
        val sharedPreferences = context.getSharedPreferences()
        val notesMap = sharedPreferences.all
        val notesList: ArrayList<Note> = arrayListOf()
        notesMap.forEach {
            notesList.add(GeneralNote(it.key, it.value as String))
        }


        return notesList
    }

    override fun save(context: Context, note: Note, onCompleted: (noteTitle: String) -> Unit, onError: (noteTitle: String) -> Unit) {
        try {

            var noteToSave: Note = note

            getAll(context).forEach {
                if (it.title == note.title) {
//                    noteToSave = note + "(second)"
                }
            }

            val sharedPreferencesEditor = context.getSharedPreferences("KotlinNotes", Context.MODE_PRIVATE).edit()
            sharedPreferencesEditor.putString(noteToSave.title, noteToSave.body)
            sharedPreferencesEditor.apply()
            onCompleted.invoke(note.title)
        } catch (e: Exception) {
            onError(note.title)
        }
    }

    override fun delete(context: Context, note: Note) {
        super<Controller>.delete(context, note)
        super<DeleteNote>.delete(context, note)
        val sharedPreferencesEditor = context.getSharedPreferences().edit()
        sharedPreferencesEditor.remove(note.title)
        sharedPreferencesEditor.apply()
    }



}