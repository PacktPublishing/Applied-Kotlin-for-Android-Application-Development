package com.yusuf.kotlinnotes;

public class SimpleClass {

    static public String getString() {
        return null;
    }

}
