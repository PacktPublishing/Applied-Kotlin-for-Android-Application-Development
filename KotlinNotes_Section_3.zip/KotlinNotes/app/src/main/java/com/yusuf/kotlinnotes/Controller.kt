package com.yusuf.kotlinnotes

import android.content.Context
import android.util.Log

interface Controller<T> {

    val sharedPrefName: String

    fun getAll(context: Context): ArrayList<T>
    fun save(context: Context, t: T, onCompleted: (noteTitle: String) -> Unit, onError: (noteTitle: String) -> Unit)
    fun delete(context: Context, t: T){
        Log.d(sharedPrefName, "Delete invoked from Controller interface")
    }

    fun Context.getSharedPreferences() = getSharedPreferences(sharedPrefName, Context.MODE_PRIVATE)
}