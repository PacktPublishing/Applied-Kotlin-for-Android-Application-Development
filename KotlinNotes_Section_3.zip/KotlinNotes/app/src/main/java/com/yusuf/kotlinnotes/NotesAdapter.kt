package com.yusuf.kotlinnotes

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class NotesAdapter(val context: Context, val notesController: NotesController, val notes: ArrayList<Note> = arrayListOf()): BaseAdapter(), Controller<Note> by notesController {

    init {
        notes.addAll(getAll(context))
    }

    override fun getItem(position: Int) = notes[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getCount() = notes.size

    override fun notifyDataSetChanged() {
        notes.clear()
        notes.addAll(getAll(context))
        super.notifyDataSetChanged()
    }

    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val note = getItem(position)
        val view = LayoutInflater.from(context).inflate(android.R.layout.simple_expandable_list_item_2, parent, false)
        view.findViewById<TextView>(android.R.id.text1).text = note.title
        view.findViewById<TextView>(android.R.id.text2).text = note.body

        view.setOnLongClickListener {
            delete(context, note)
            notifyDataSetChanged()
            true
        }

        view.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                NoteActivity().openNoteDetail(context, note)
            }

        })

        return view
    }
}