package com.yusuf.kotlinnotes

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listfab.setOnClickListener {
            NoteActivity().openNoteDetail(this, ListNote(""))
        }

        fab.setOnClickListener {
            if (it == fab) {
                NoteActivity().newNote(this@MainActivity)
            }
        }

        PreNotes.values().forEach {
            NotesController.save(this, it.note, {}, {})
        }

//        doSomething()
    }

    fun doSomething() {

        NoteType.values().forEach {
            it.showToast(this)
        }

    }

    override fun onResume() {
        super.onResume()
        val adapter = NotesAdapter(this, NotesController)

        adapter.getAll(this)

        list.adapter = adapter
    }
}
