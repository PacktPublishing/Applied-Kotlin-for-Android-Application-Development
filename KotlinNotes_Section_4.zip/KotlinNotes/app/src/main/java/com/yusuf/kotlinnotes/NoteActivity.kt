package com.yusuf.kotlinnotes

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_note.*
import org.jetbrains.anko.share
import org.jetbrains.anko.toast

class NoteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note)

        val note = intent.extras?.getSerializable("note") as Note?

        if (note != null) {
            noteTitle.setText(note.title)
            noteBody.setText(note.body)
        }

        btnDelete.setOnClickListener {
            if (note != null) {
                NotesController.delete(this, note)
                setResult(Activity.RESULT_CANCELED)
                finish()
            }
        }

        btnSave.setOnClickListener {

//            if (note != null && (note.title != noteTitle.text.toString() ||
//                            note.body != noteBody.text.toString())) {
//                NotesController.delete(this, note)
//            }

            NotesController.save(this, GeneralNote(noteTitle.text.toString(), noteBody.text.toString()),
                    onCompleted = {
//                        toast("Saved note $it")
//                        Toast.makeText(this, "Saved note $it", Toast.LENGTH_SHORT).show()
                        setResult(Activity.RESULT_OK)
                        finish()
                    },
                    onError = {
//                        toast("Error saving $it")
//                        Toast.makeText(this, , Toast.LENGTH_SHORT).show()
                    })
        }

        sharefab.setOnClickListener {
            if (note != null) {
                share("${note.title}\n\n${note.body}", "Share note...")
            } else {
                toast("Cannot share an empty note!")
            }
        }
    }


    fun openNoteDetail(context: Context, note: Note) {
        val intent = Intent(context, NoteActivity::class.java)
        intent.putExtra("note", note)
        context.startActivity(intent)
    }

    fun newNote(context: Context) {
        context.startActivity(Intent(context, NoteActivity::class.java))
    }
}
