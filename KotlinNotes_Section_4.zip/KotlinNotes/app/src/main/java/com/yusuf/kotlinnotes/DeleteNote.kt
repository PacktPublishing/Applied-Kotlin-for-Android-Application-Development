package com.yusuf.kotlinnotes

import android.content.Context
import android.util.Log

interface DeleteNote {

    fun delete(context: Context, note: Note) {
        Log.d("DeleteNote Interface", "Invoked delete function")
    }

}