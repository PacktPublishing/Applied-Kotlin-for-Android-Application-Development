package com.yusuf.kotlinnotes

enum class PreNotes(val note: Note) {

    WELCOME(GeneralNote("Welcome", "Welcome to the notes app!")),
    WELCOME_LIST(ListNote("You can create a list!")),
    LONG_NOTE(GeneralNote("Log your thoughts", "Dear diary,\n\nToday was a great day...")),
    LONG_EXAMPLE(GeneralNote("Long press me to delete", "Hold and press me to delete this note"))


}