package com.yusuf.kotlinnotes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.coroutines.experimental.bg
import org.jetbrains.anko.design.longSnackbar
import org.jetbrains.anko.info
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.selector

class MainActivity : AppCompatActivity() {

//    override val loggerTag = "ourCustomTag"

    val logger = AnkoLogger<MainActivity>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        Log.d(TAG, "onCreate() MainActivity")

        bg {
            logger.info { "inside AnkoLogger on Thread ${Thread.currentThread().name}" }

            runOnUiThread {
                logger.info { "inside AnkoLogger on Thread ${Thread.currentThread().name}" }
            }
        }


//        logger.info("Inside parantheses")

        fab.setOnClickListener {
            val noteTypes = listOf("General Note", "List Note")
            selector("Select note type...", noteTypes, {
                dialogInterface, i ->
                run {
                    when (i) {
                        0 -> {
                            startActivityForResult(intentFor<NoteActivity>(), 1)
                        }
                        1 -> {
                            startActivityForResult(intentFor<NoteActivity>("note" to ListNote("")), 1)
                        }
                    }
                }
            })

        }

        PreNotes.values().forEach {
            NotesController.save(this, it.note, {}, {})
        }

    }


    override fun onResume() {
        super.onResume()
        val adapter = NotesAdapter(this, NotesController)

        adapter.getAll(this)

        list.adapter = adapter
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            Activity.RESULT_OK -> {
//                toast("Note saved!")
//                alert("Note saved!") {
//                    yesButton { }
//                    noButton { }
//                }.show()
                longSnackbar(list, "Note saved!", "OK") {  }

            }

            Activity.RESULT_CANCELED -> {
//                toast("Note deleted!")
//                alert("Note deleted!").show()
                longSnackbar(list, "Note deleted!", "OK") { }
            }
        }
    }

}
